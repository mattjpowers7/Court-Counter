package com.example.android.courtcounter;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

import java.text.NumberFormat;

public class KeepingScore extends AppCompatActivity {

    int scoreA = 0;
    int scoreB = 0;
    int outsA = 0;
    int outsB = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_keeping_score);
        displayForTeamA(0);
    }

    public void addtwo(View view) {
        scoreA = scoreA + 2;
        displayForTeamA(scoreA);
    }

    public void addone(View view) {
        scoreA = scoreA + 1;
        displayForTeamA(scoreA);
    }

    public void Outa(View view) {
        outsA = outsA + 1;
        displayOutsA(outsA);
    }

    public void displayOutsA(int outsA) {
        TextView scoreView = (TextView) findViewById(R.id.team_a_outs);
        scoreView.setText(String.valueOf(outsA));
    }

    public void Outb(View view) {
        outsB = outsB + 1;
        displayOutsB(outsB);
    }

    public void displayOutsB(int outsB) {
        TextView scoreView = (TextView) findViewById(R.id.team_b_outs);
        scoreView.setText(String.valueOf(outsB));
    }

    public void displayForTeamA(int scoreA) {
        TextView scoreView = (TextView) findViewById(R.id.team_a_score);
        scoreView.setText(String.valueOf(scoreA));
    }

    public void addtwob(View view) {
        scoreB = scoreB + 2;
        displayForTeamB(scoreB);
    }

    public void addoneb(View view) {
        scoreB = scoreB + 1;
        displayForTeamB(scoreB);
    }

    public void resetScore(View v) {
        outsA = 0;
        outsB = 0;
        scoreA = 0;
        scoreB = 0;
        displayForTeamA(scoreA);
        displayForTeamB(scoreB);
    }

    public void displayForTeamB(int scoreB) {
        TextView scoreView = (TextView) findViewById(R.id.team_b_score);
        scoreView.setText(String.valueOf(scoreB));
    }
}

